document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('regUsername').value;
  const password = document.getElementById('regPassword').value;
  await fetch('/api/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  alert('Registered!');
});

let token = '';

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;
  const res = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  const data = await res.json();
  token = data.token;
  alert('Logged in!');
});

document.getElementById('getProtected').addEventListener('click', async () => {
  const res = await fetch('/api/protected', {
    headers: { Authorization: 'Bearer ' + token }
  });
  const text = await res.text();
  document.getElementById('protectedOutput').textContent = text;
});