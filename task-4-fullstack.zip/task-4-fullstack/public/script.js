document.getElementById('registerForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const feedback = document.getElementById('feedback');

  const passwordStrong = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;

  if (!passwordStrong.test(password)) {
    feedback.textContent = "Password must contain 6+ characters, including uppercase, number, and symbol.";
    feedback.style.color = 'red';
  } else if (!email.includes('@')) {
    feedback.textContent = "Invalid email address.";
    feedback.style.color = 'red';
  } else {
    feedback.textContent = `Registration successful! Welcome, ${username}`;
    feedback.style.color = 'green';
    document.getElementById('registerForm').reset();
  }
});

function navigate(pageId) {
  document.querySelectorAll('.page').forEach(p => p.style.display = 'none');
  document.getElementById(pageId).style.display = 'block';
}