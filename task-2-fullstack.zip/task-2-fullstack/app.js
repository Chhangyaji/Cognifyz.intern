const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

let submittedData = [];

app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('form', { error: null });
});

app.post('/submit', (req, res) => {
  const { name, email } = req.body;

  // Server-side validation
  if (!name || !email || !email.includes('@')) {
    return res.render('form', { error: 'Please enter a valid name and email.' });
  }

  submittedData.push({ name, email });
  res.render('success', { name, email });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});