document.addEventListener('DOMContentLoaded', () => {
  const userList = document.getElementById('userList');
  const userForm = document.getElementById('userForm');
  const usernameInput = document.getElementById('username');

  const fetchUsers = async () => {
    const res = await fetch('/api/users');
    const users = await res.json();
    userList.innerHTML = '';
    users.forEach(user => {
      const li = document.createElement('li');
      li.innerHTML = \`\${user.name} <button onclick="deleteUser(\${user.id})">Delete</button>\`;
      userList.appendChild(li);
    });
  };

  userForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = usernameInput.value.trim();
    if (!name) return;

    await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });

    usernameInput.value = '';
    fetchUsers();
  });

  window.deleteUser = async (id) => {
    await fetch(\`/api/users/\${id}\`, { method: 'DELETE' });
    fetchUsers();
  };

  fetchUsers();
});